import './Zap.css'

function Botao() {
  return (
    <button className="botaoOpt">
     <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 512"><path d="M64 360a56 56 0 1 0 0 112 56 56 0 1 0 0-112zm0-160a56 56 0 1 0 0 112 56 56 0 1 0 0-112zM120 96A56 56 0 1 0 8 96a56 56 0 1 0 112 0z"/></svg>
    </button>
  );
}

function Mensagem({ descricao, recebido, visualizado }) {
  return (
    <li className={'message ' + (recebido ? 'recebido' : 'enviado')}>
      {descricao}
      <button className="options">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M233.4 406.6c12.5 12.5 32.8 12.5 45.3 0l192-192c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L256 338.7 86.6 169.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l192 192z"/></svg>
      </button>

       <span className={'visualized' + (visualizado ? ' yes' : '')}>
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M374.6 86.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 178.7l-57.4-57.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l80 80c12.5 12.5 32.8 12.5 45.3 0l160-160zm96 128c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0L192 402.7 86.6 297.4c-12.5-12.5-32.8-12.5-45.3 0s-12.5 32.8 0 45.3l128 128c12.5 12.5 32.8 12.5 45.3 0l256-256z"/></svg>
      </span>
    </li>
  );
}

function App (){
    const mensagens = [
        {
            id: 1,
            descricao: "Oi...",
            recebido: true,
            visualizado: true
        },
        {
           id: 2,
            descricao: "Tu não me ama mais?",
            recebido: true,
            visualizado: true
        },
        {
           id: 3,
            descricao: "Oi, boa tarde",
            recebido: false,
            visualizado: false
        },
         {
           id: 4,
            descricao: "Quem é você mesmo?",
            recebido: false,
            visualizado: false
        }
    ]

    return(
            <div className = "chat">
            <div className = "header">
                <Botao />
                <h3>Meu Chat</h3>
            </div>
            <div className = "content"></div>
            <ul>
                {mensagens.map(msg => (
                    <Mensagem
                        id={msg.id}
                        descricao={msg.descricao}
                        recebido={msg.recebido}
                        visualizado={msg.visualizado}
                    />
                ))}
            </ul>
        </div>
    )
}

export default App;